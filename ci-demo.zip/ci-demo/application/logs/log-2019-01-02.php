<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-02 07:15:30 --> 404 Page Not Found: Users/index
